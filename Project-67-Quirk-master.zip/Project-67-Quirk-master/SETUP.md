# iOS Setup

You'll need to install [Cocoapods](https://cocoapods.org/) if you haven't
already. You can do that by running:

```
sudo gem install cocoapods -v 1.5.3
```

That version is fairly important.

Then install the depenedencies with:

```
cd ./ios;
pod install;
```
